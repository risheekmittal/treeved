package com.example.treeved

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
